import React, { useState, useRef, useEffect } from 'react';
import { Send, Plus, Menu, Moon, Sun, Copy, Trash2, MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import ChatMessage from './ChatMessage';
import ConversationSidebar from './ConversationSidebar';
import { GeminiService } from '@/services/gemini';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

const ChatInterface: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [typingMessage, setTypingMessage] = useState('');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const currentConversation = conversations.find(c => c.id === currentConversationId);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentConversation?.messages, typingMessage]);

  // Theme toggle effect
  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode);
  }, [isDarkMode]);

  // Focus input on conversation change
  useEffect(() => {
    inputRef.current?.focus();
  }, [currentConversationId]);

  const generateConversationTitle = (firstMessage: string): string => {
    return firstMessage.length > 50 
      ? firstMessage.substring(0, 50) + '...'
      : firstMessage;
  };

  const createNewConversation = (): Conversation => {
    const newConversation: Conversation = {
      id: `conv_${Date.now()}`,
      title: 'New Conversation',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    setConversations(prev => [newConversation, ...prev]);
    setCurrentConversationId(newConversation.id);
    return newConversation;
  };

  const updateConversationTitle = (conversationId: string, title: string) => {
    setConversations(prev => 
      prev.map(conv => 
        conv.id === conversationId 
          ? { ...conv, title, updatedAt: new Date() }
          : conv
      )
    );
  };

  const addMessage = (conversationId: string, message: Message) => {
    setConversations(prev => 
      prev.map(conv => 
        conv.id === conversationId 
          ? { 
              ...conv, 
              messages: [...conv.messages, message],
              updatedAt: new Date() 
            }
          : conv
      )
    );
  };

  const simulateTyping = async (text: string, onComplete: () => void) => {
    setTypingMessage('');
    const words = text.split(' ');
    
    for (let i = 0; i < words.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 100));
      setTypingMessage(prev => prev + (i > 0 ? ' ' : '') + words[i]);
    }
    
    setTimeout(() => {
      setTypingMessage('');
      onComplete();
    }, 500);
  };

  const handleSendMessage = async () => {
    if (!message.trim() || isLoading) return;

    const userMessage = message.trim();
    setMessage('');
    setIsLoading(true);

    try {
      // Get or create conversation
      let conversation = currentConversation;
      if (!conversation) {
        conversation = createNewConversation();
      }

      // Add user message
      const userMsg: Message = {
        id: `msg_${Date.now()}`,
        content: userMessage,
        role: 'user',
        timestamp: new Date(),
      };
      
      addMessage(conversation.id, userMsg);

      // Update conversation title if it's the first message
      if (conversation.messages.length === 0) {
        updateConversationTitle(conversation.id, generateConversationTitle(userMessage));
      }

      // Get AI response
      const response = await GeminiService.sendMessage(userMessage);
      
      // Simulate typing animation
      await simulateTyping(response, () => {
        const aiMsg: Message = {
          id: `msg_${Date.now() + 1}`,
          content: response,
          role: 'assistant',
          timestamp: new Date(),
        };
        
        addMessage(conversation!.id, aiMsg);
        setIsLoading(false);
      });

    } catch (error) {
      console.error('Error sending message:', error);
      setIsLoading(false);
      setTypingMessage('');
      
      toast({
        title: "Error",
        description: "Failed to send message. Please check your API key and try again.",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearCurrentConversation = () => {
    if (!currentConversationId) return;
    
    setConversations(prev => 
      prev.map(conv => 
        conv.id === currentConversationId 
          ? { ...conv, messages: [], updatedAt: new Date() }
          : conv
      )
    );
    
    toast({
      title: "Conversation cleared",
      description: "All messages have been removed from this conversation.",
    });
  };

  const deleteConversation = (conversationId: string) => {
    setConversations(prev => prev.filter(conv => conv.id !== conversationId));
    
    if (currentConversationId === conversationId) {
      const remainingConversations = conversations.filter(conv => conv.id !== conversationId);
      setCurrentConversationId(remainingConversations[0]?.id || null);
    }
    
    toast({
      title: "Conversation deleted",
      description: "The conversation has been permanently removed.",
    });
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({
      title: "Copied!",
      description: "Message copied to clipboard.",
    });
  };

  return (
    <div className="flex h-screen bg-chat-background">
      {/* Sidebar */}
      <ConversationSidebar
        conversations={conversations}
        currentConversationId={currentConversationId}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        onNewConversation={createNewConversation}
        onSelectConversation={setCurrentConversationId}
        onDeleteConversation={deleteConversation}
        isDarkMode={isDarkMode}
        onThemeToggle={() => setIsDarkMode(!isDarkMode)}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-border bg-surface">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-lg font-semibold text-text-primary">Code Hira AI</h1>
              <p className="text-sm text-text-secondary">AI Assistant by Hira</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {currentConversation && currentConversation.messages.length > 0 && (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={clearCurrentConversation}
                  className="text-text-secondary hover:text-destructive"
                  title="Clear conversation"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <div className="w-px h-6 bg-border mx-2" />
              </>
            )}
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="text-text-secondary hover:text-text-primary"
            >
              {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
          </div>
        </header>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {!currentConversation || currentConversation.messages.length === 0 ? (
            <div className="flex-1 flex items-center justify-center">
              <Card className="p-8 max-w-lg text-center bg-gradient-surface border-border/50">
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto">
                    <span className="text-2xl font-bold text-primary-foreground">H</span>
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-text-primary mb-2">
                      Welcome to Code Hira AI
                    </h2>
                    <p className="text-text-secondary">
                      I'm your AI coding assistant. Ask me anything about programming, 
                      get code examples, debug issues, or discuss software architecture.
                    </p>
                  </div>
                  <div className="grid grid-cols-1 gap-2 mt-6">
                    <button
                      onClick={() => setMessage("Help me write a React component")}
                      className="p-3 text-left bg-surface-secondary hover:bg-sidebar-item-hover rounded-lg transition-colors text-text-secondary hover:text-text-primary"
                    >
                      💻 Help me write a React component
                    </button>
                    <button
                      onClick={() => setMessage("Explain async/await in JavaScript")}
                      className="p-3 text-left bg-surface-secondary hover:bg-sidebar-item-hover rounded-lg transition-colors text-text-secondary hover:text-text-primary"
                    >
                      🔍 Explain async/await in JavaScript
                    </button>
                    <button
                      onClick={() => setMessage("Review my code for best practices")}
                      className="p-3 text-left bg-surface-secondary hover:bg-sidebar-item-hover rounded-lg transition-colors text-text-secondary hover:text-text-primary"
                    >
                      ✨ Review my code for best practices
                    </button>
                  </div>
                </div>
              </Card>
            </div>
          ) : (
            <>
              {currentConversation.messages.map((msg) => (
                <ChatMessage
                  key={msg.id}
                  message={msg}
                  onCopy={() => copyMessage(msg.content)}
                />
              ))}
              
              {/* Typing indicator */}
              {typingMessage && (
                <ChatMessage
                  message={{
                    id: 'typing',
                    content: typingMessage,
                    role: 'assistant',
                    timestamp: new Date(),
                  }}
                  isTyping={true}
                  onCopy={() => {}}
                />
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 border-t border-border bg-surface">
          <div className="max-w-4xl mx-auto">
            <div className="relative flex items-end gap-3">
              <div className="flex-1 relative">
                <Input
                  ref={inputRef}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message here..."
                  disabled={isLoading}
                  className="pr-12 min-h-[48px] bg-input border-input-border focus:border-input-focus focus:ring-2 focus:ring-input-focus/20 resize-none"
                />
              </div>
              
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim() || isLoading}
                className="h-12 w-12 bg-gradient-primary hover:bg-primary-hover disabled:opacity-50 disabled:cursor-not-allowed shadow-glow"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            
            <p className="text-xs text-text-tertiary mt-2 text-center">
              Press Enter to send, Shift+Enter for new line
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;