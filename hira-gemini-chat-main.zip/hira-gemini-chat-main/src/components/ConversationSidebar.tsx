import React, { useState } from 'react';
import { Plus, MessageSquare, Trash2, MoreVertical, Moon, Sun, X, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

interface ConversationSidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  isOpen: boolean;
  onToggle: () => void;
  onNewConversation: () => void;
  onSelectConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  isDarkMode: boolean;
  onThemeToggle: () => void;
}

const ConversationSidebar: React.FC<ConversationSidebarProps> = ({
  conversations,
  currentConversationId,
  isOpen,
  onToggle,
  onNewConversation,
  onSelectConversation,
  onDeleteConversation,
  isDarkMode,
  onThemeToggle,
}) => {
  const [hoveredConversation, setHoveredConversation] = useState<string | null>(null);

  const formatDate = (date: Date): string => {
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const groupedConversations = conversations.reduce((groups, conversation) => {
    const dateKey = formatDate(conversation.updatedAt);
    if (!groups[dateKey]) {
      groups[dateKey] = [];
    }
    groups[dateKey].push(conversation);
    return groups;
  }, {} as Record<string, Conversation[]>);

  if (!isOpen) {
    return (
      <div className="w-16 bg-sidebar-background border-r border-border flex flex-col items-center py-4 space-y-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggle}
          className="w-10 h-10 hover:bg-sidebar-item-hover"
        >
          <Menu className="h-5 w-5 text-sidebar-foreground" />
        </Button>
        
        <Button
          variant="ghost"
          size="icon"
          onClick={onNewConversation}
          className="w-10 h-10 hover:bg-sidebar-item-hover"
        >
          <Plus className="h-4 w-4 text-sidebar-foreground" />
        </Button>
        
        <div className="flex-1" />
        
        <Button
          variant="ghost"
          size="icon"
          onClick={onThemeToggle}
          className="w-10 h-10 hover:bg-sidebar-item-hover"
        >
          {isDarkMode ? (
            <Sun className="h-4 w-4 text-sidebar-foreground" />
          ) : (
            <Moon className="h-4 w-4 text-sidebar-foreground" />
          )}
        </Button>
      </div>
    );
  }

  return (
    <>
      {/* Mobile overlay */}
      <div 
        className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
        onClick={onToggle}
      />
      
      {/* Sidebar */}
      <div className="w-80 bg-sidebar-background border-r border-border flex flex-col h-full relative z-50 animate-slide-in">
        {/* Header */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-sidebar-foreground">
              Conversations
            </h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggle}
              className="lg:hidden w-8 h-8 hover:bg-sidebar-item-hover"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          <Button
            onClick={onNewConversation}
            className="w-full bg-gradient-primary hover:bg-primary-hover text-primary-foreground shadow-glow"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Conversation
          </Button>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {Object.keys(groupedConversations).length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="h-12 w-12 mx-auto text-text-tertiary mb-4" />
              <p className="text-text-secondary">No conversations yet</p>
              <p className="text-sm text-text-tertiary mt-1">
                Start a new conversation to begin
              </p>
            </div>
          ) : (
            Object.entries(groupedConversations).map(([dateGroup, convs]) => (
              <div key={dateGroup} className="space-y-2">
                <h3 className="text-xs font-medium text-text-tertiary uppercase tracking-wider">
                  {dateGroup}
                </h3>
                
                <div className="space-y-1">
                  {convs.map((conversation) => (
                    <div
                      key={conversation.id}
                      className="relative group"
                      onMouseEnter={() => setHoveredConversation(conversation.id)}
                      onMouseLeave={() => setHoveredConversation(null)}
                    >
                      <Card
                        className={`p-3 cursor-pointer transition-all border-0 ${
                          currentConversationId === conversation.id
                            ? 'bg-sidebar-item-active text-sidebar-item-active-foreground shadow-glow'
                            : 'bg-transparent hover:bg-sidebar-item-hover text-sidebar-foreground'
                        }`}
                        onClick={() => onSelectConversation(conversation.id)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium truncate text-sm">
                              {conversation.title}
                            </h4>
                            <p className="text-xs opacity-70 truncate mt-1">
                              {conversation.messages.length > 0
                                ? conversation.messages[conversation.messages.length - 1].content.substring(0, 60) + '...'
                                : 'No messages'
                              }
                            </p>
                          </div>
                          
                          {hoveredConversation === conversation.id && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 ml-2"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <MoreVertical className="h-3 w-3" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDeleteConversation(conversation.id);
                                  }}
                                  className="text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </div>
                      </Card>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-sidebar-foreground">Hira</p>
              <p className="text-xs text-text-tertiary">Owner</p>
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={onThemeToggle}
              className="hover:bg-sidebar-item-hover"
            >
              {isDarkMode ? (
                <Sun className="h-4 w-4 text-sidebar-foreground" />
              ) : (
                <Moon className="h-4 w-4 text-sidebar-foreground" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ConversationSidebar;