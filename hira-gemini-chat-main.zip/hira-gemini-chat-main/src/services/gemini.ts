// Gemini API Service
// This service handles all interactions with Google's Gemini API

interface GeminiResponse {
  candidates: {
    content: {
      parts: {
        text: string;
      }[];
    };
  }[];
}

interface RateLimitError extends Error {
  isRateLimit: boolean;
}

export class GeminiService {
  private static readonly API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
  private static apiKey: string | null = null;
  
  // Initialize with API key
  static setApiKey(key: string) {
    this.apiKey = key;
    localStorage.setItem('gemini_api_key', key);
  }
  
  // Get API key from localStorage or prompt user
  static getApiKey(): string | null {
    if (this.apiKey) return this.apiKey;
    
    const stored = localStorage.getItem('gemini_api_key');
    if (stored) {
      this.apiKey = stored;
      return stored;
    }
    
    return null;
  }
  
  // Check if API key is configured
  static isConfigured(): boolean {
    return !!this.getApiKey();
  }
  
  // Remove API key
  static clearApiKey() {
    this.apiKey = null;
    localStorage.removeItem('gemini_api_key');
  }
  
  // Send message to Gemini API
  static async sendMessage(message: string): Promise<string> {
    const apiKey = this.getApiKey();
    
    if (!apiKey) {
      // Prompt user for API key
      const userApiKey = prompt(
        'Please enter your Google Gemini API key:\n\n' +
        'To get your API key:\n' +
        '1. Go to https://aistudio.google.com/app/apikey\n' +
        '2. Create a new API key\n' +
        '3. Copy and paste it here\n\n' +
        'Your API key will be stored locally in your browser.'
      );
      
      if (!userApiKey) {
        throw new Error('API key is required to use the AI assistant');
      }
      
      this.setApiKey(userApiKey.trim());
    }
    
    try {
      const response = await fetch(`${this.API_ENDPOINT}?key=${this.getApiKey()}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `You are "Code Hira AI", a helpful AI coding assistant created by Hira. You specialize in programming, software development, code review, debugging, and technical explanations. 

You should:
- Provide clear, concise, and accurate programming help
- Use proper markdown formatting for code blocks with language syntax highlighting
- Be friendly and professional in your responses
- Focus on best practices and clean code principles
- Explain complex concepts in an easy-to-understand way

User message: ${message}`
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 2048,
          },
          safetySettings: [
            {
              category: "HARM_CATEGORY_HARASSMENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_HATE_SPEECH",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
              category: "HARM_CATEGORY_DANGEROUS_CONTENT",
              threshold: "BLOCK_MEDIUM_AND_ABOVE"
            }
          ]
        }),
      });
      
      if (!response.ok) {
        if (response.status === 429) {
          const error = new Error('Rate limit exceeded. Please try again later.') as RateLimitError;
          error.isRateLimit = true;
          throw error;
        }
        
        if (response.status === 400) {
          const errorData = await response.json().catch(() => ({}));
          if (errorData.error?.message?.includes('API_KEY_INVALID')) {
            this.clearApiKey();
            throw new Error('Invalid API key. Please check your Gemini API key and try again.');
          }
        }
        
        throw new Error(`API request failed with status ${response.status}`);
      }
      
      const data: GeminiResponse = await response.json();
      
      if (!data.candidates || data.candidates.length === 0) {
        throw new Error('No response generated');
      }
      
      const text = data.candidates[0]?.content?.parts?.[0]?.text;
      
      if (!text) {
        throw new Error('Empty response from API');
      }
      
      return text.trim();
      
    } catch (error) {
      console.error('Gemini API Error:', error);
      
      if (error instanceof Error) {
        if ((error as RateLimitError).isRateLimit) {
          throw error;
        }
        
        if (error.message.includes('API_KEY_INVALID') || error.message.includes('API key')) {
          this.clearApiKey();
        }
        
        throw error;
      }
      
      throw new Error('Failed to communicate with AI service');
    }
  }
  
  // Test API connection
  static async testConnection(): Promise<boolean> {
    try {
      await this.sendMessage('Hello, please respond with "Connection successful"');
      return true;
    } catch (error) {
      console.error('Connection test failed:', error);
      return false;
    }
  }
}

export default GeminiService;